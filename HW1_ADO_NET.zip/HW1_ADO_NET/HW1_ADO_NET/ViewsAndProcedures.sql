﻿--Создаем представления
--Отображение всей информации из таблицы с овощами и фруктами

CREATE VIEW [GetAllData] AS
SELECT * FROM [dbo].[VegFruits];

--Отображение всех названий овощей и фруктов

CREATE VIEW [GetNames] AS
SELECT [Name] FROM [VegFruits];

--Отображение всех цветов

CREATE VIEW [GetColors] AS
SELECT [Color] FROM [VegFruits];

--Показать максимальную калорийность

CREATE VIEW [GetMaxCalorieValue] AS
SELECT TOP 1 [Calorie_Content]
FROM [VegFruits]
ORDER BY [Calorie_Content] DESC;

--Показать минимальную калорийность

CREATE VIEW [GetMinCalorieValue] AS
SELECT TOP 1 [Calorie_Content]
FROM [VegFruits]
ORDER BY [Calorie_Content];

--Показать среднюю калорийность

CREATE VIEW [GetAverageCalorieValue] AS
SELECT AVG(DISTINCT [Calorie_Content]) AS [Average_Calorie_Content] 
FROM [VegFruits];

--Показать количество овощей

CREATE VIEW [GetVegetablesCount] AS
SELECT COUNT(DISTINCT [Name]) AS [Vegetables_Count]
FROM [VegFruits]
WHERE [Type] = 'овощ';

--Показать количество фруктов

CREATE VIEW [GetFruitsCount] AS
SELECT COUNT(DISTINCT [Name]) AS [Fruits_Count]
FROM [VegFruits]
WHERE [Type] = 'фрукт';

--Показать количество овощей и фруктов заданного цвета

CREATE PROC [GetNamesCountByColor] 
	@color NVARCHAR(100)
AS
BEGIN
	SELECT COUNT([Name]) AS [Count]
	FROM [VegFruits]
	WHERE [Color] = @color;
END;

--Показать количество овощей и фруктов каждого цвета

CREATE VIEW [GetNamesCountGroupByColor] AS
SELECT [Color], COUNT([Name]) AS [Count]
FROM [VegFruits]
GROUP BY [Color];

--Показать овощи и фрукты с калорийностью ниже указанной

CREATE PROC [GetNamesWithLowerCaloriesThatIndicated] 
	@calories INT
AS
BEGIN
	SELECT [Name]
	FROM [VegFruits]
	WHERE [Calorie_Content] < @calories;
END;

--Показать овощи и фрукты с калорийностью выше указанной

CREATE PROC [GetNamesWithHigherCaloriesThatIndicated] 
	@calories INT
AS
BEGIN
	SELECT [Name]
	FROM [VegFruits]
	WHERE [Calorie_Content] > @calories;
END;

--Показать овощи и фрукты с калорийностью в указанном диапазоне

CREATE PROC [GetNamesWithCaloriesBetweenSpecifiedBoundaries] 
	@caloriesBottom INT,
	@caloriesUpper INT
AS
BEGIN
	SELECT [Name]
	FROM [VegFruits]
	WHERE [Calorie_Content] > @caloriesBottom AND [Calorie_Content] < @caloriesUpper;
END;

--Показать все овощи и фрукты, у которых цвет желтый или красный

CREATE VIEW [GetNamesRedYellowColor] AS
SELECT [Name]
FROM [VegFruits]
WHERE [Color] = 'желтый' OR [Color] = 'красный';
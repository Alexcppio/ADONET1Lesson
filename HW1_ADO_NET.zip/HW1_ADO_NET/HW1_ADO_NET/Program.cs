﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace HW1_ADO_NET
{
    class Program
    {
        static void Main(string[] args)
        {
            var appStart = new ConsoleMenu();
        }
    }
}

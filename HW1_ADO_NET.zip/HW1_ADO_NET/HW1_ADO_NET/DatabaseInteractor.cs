﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace HW1_ADO_NET
{
    public class DatabaseInteractor
    {
        public int QuerySelector { get; }
        public int FirstBorder { get; }
        public int SecondBorder { get; }
        public string TextValue { get; }
        enum Queries
        {
            GetAllData = 1,
            GetNames = 2,
            GetColors = 3,
            GetMaxCalorieValue = 4,
            GetMinCalorieValue = 5,
            GetAverageCalorieValue = 6,
            GetVagetablesCount = 7,
            GetFruitsCount = 8,
            GetNamesCountByColor = 9,
            GetNamesCountGroupByColor = 10,
            GetNamesWithLowerCaloriesThatIndicated = 11,
            GetNamesWithHigherCaloriesThatIndicated = 12,
            GetNamesWithCaloriesBetweenSpecifiedBoundaries = 13,
            GetNamesRedYellowColor = 14
        }

        public DatabaseInteractor(int querySelector)
        {
            QuerySelector = querySelector;
        }
        public DatabaseInteractor(int querySelector, int firstBorder) : this(querySelector)
        {
            FirstBorder = firstBorder;
        }
        public DatabaseInteractor(int querySelector, int firstBorder, int secondBorder) : this(querySelector, firstBorder)
        {
            SecondBorder = secondBorder;
        }
        public DatabaseInteractor(int querySelector, string textValue) : this(querySelector)
        {
            TextValue = textValue;
        }

        public string ReceiveData()
        {
            var table = "";
            using (var conn = new SqlConnection(@"Data Source=DESKTOP-4KS5O09\SQLEXPRESS;Initial Catalog=VegFruits;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;"))
            {
                var query = Enum.GetName(typeof(Queries), QuerySelector);
                // открываем соединение
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                if (QuerySelector == 11 || QuerySelector == 12)
                {
                    cmd = CreateProcQuery(cmd, query);
                    cmd.Parameters.Add("@calories", System.Data.SqlDbType.Int).Value = FirstBorder;
                }
                else if (QuerySelector == 9)
                {
                    cmd = CreateProcQuery(cmd, query);
                    cmd.Parameters.Add("@color", System.Data.SqlDbType.NVarChar).Value = TextValue;
                }
                else if (QuerySelector == 13)
                {
                    cmd = CreateProcQuery(cmd, query);
                    cmd.Parameters.Add("@caloriesBottom", System.Data.SqlDbType.Int).Value = FirstBorder;
                    cmd.Parameters.Add("@caloriesUpper", System.Data.SqlDbType.Int).Value = SecondBorder;
                }
                else
                    cmd.CommandText = CreateViewQuery(query);

                // Наполняем строку из базы
                SqlDataReader sqlReader = cmd.ExecuteReader();
                var lineCounter = 0;

                while (sqlReader.Read())
                {
                    if (lineCounter == 0)
                    {
                        for (int i = 0; i < sqlReader.FieldCount; i++)
                        {
                            table += FormateTabs(sqlReader.GetName(i).ToString());
                        }
                        table += "\n";
                    }
                    else
                    {
                        for (int i = 0; i < sqlReader.FieldCount; i++)
                        {
                            table += FormateTabs(sqlReader[i].ToString());
                        }
                        table += "\n";
                    }
                    lineCounter++;
                }
                // закрываем соединение
                conn.Close();
            }
            return table;
        }

        private string CreateViewQuery(string query)
        {
            return $"SELECT * FROM [{query}];";
        }

        private SqlCommand CreateProcQuery(SqlCommand cmd, string query)
        {
            cmd.CommandText = $"[{query}]";
            cmd.CommandType = CommandType.StoredProcedure;
            return cmd;
        }

        private string FormateTabs(string tableCell)
        {
            var newCell = "";
            if (tableCell.Length < 8)
                newCell = tableCell + "\t\t";
            else
                newCell = tableCell + "\t";
            return newCell;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HW1_ADO_NET
{
    class ConsoleMenu
    {
        private readonly string[] menuItems = 
        { 
            "Отображение всей информации из таблицы с овощами и фруктами",
            "Отображение всех названий овощей и фруктов",
            "Отображение всех цветов",
            "Показать максимальную калорийность",
            "Показать минимальную калорийность",
            "Показать среднюю калорийность",
            "Показать количество овощей",
            "Показать количество фруктов",
            "Показать количество овощей и фруктов заданного цвета",
            "Показать количество овощей и фруктов каждого цвета",
            "Показать овощи и фрукты с калорийностью ниже указанной",
            "Показать овощи и фрукты с калорийностью выше указанной",
            "Показать овощи и фрукты с калорийностью в указанном диапазоне",
            "Показать все овощи и фрукты, у которых цвет желтый или красный"
        };

        private readonly string[] returnItems =
        {
            "Вернуться в меню",
            "Закрыть"
        };

        public ConsoleMenu() => ShowMenu();

        private void ShowMenu()
        {
            do
            {
                Console.WriteLine("База калорийности фруктов и овощей.\nВведите команду:\n");
                for (var i = 0; i < menuItems.Length; i++)
                    Console.WriteLine($"{i + 1} - {menuItems[i]}");

                var inputValue = InputHandler(menuItems.Length);
                if (inputValue != -1)
                    CreateSubMenu(inputValue);
                else if (inputValue == -1)
                    Console.WriteLine("Неправильный ввод\n");

            } while (true);
        }

        private void CreateSubMenu(int input)
        {
            int exitInputValue;
            DatabaseInteractor newQuery;
            string tableData = "";
            do
            {
                if (input == 11 || input == 12)
                {
                    Console.WriteLine("Введите границу:\n");
                    var firstBorder = InputHandler(null);
                    if (firstBorder != -1)
                    {
                        newQuery = new DatabaseInteractor(input, firstBorder);
                        tableData = newQuery.ReceiveData();
                    }
                    else if (firstBorder == -1)
                        Console.WriteLine("Неправильный ввод\n");
                }
                else if (input == 9)
                {
                    Console.WriteLine("Введите цвет:\n");
                    var color = Console.ReadLine();
                    newQuery = new DatabaseInteractor(input, color);
                    tableData = newQuery.ReceiveData();
                }
                else if (input == 13)
                {
                    Console.WriteLine("Введите первую границу:\n");
                    var firstBorder = InputHandler(null);

                    Console.WriteLine("Введите вторую границу:\n");
                    var secondBorder = InputHandler(null);

                    if (firstBorder != -1 && secondBorder != -1)
                    {
                        newQuery = new DatabaseInteractor(input, firstBorder, secondBorder);
                        tableData = newQuery.ReceiveData();
                    }
                    else if (firstBorder == -1 || secondBorder == -1)
                        Console.WriteLine("Неправильный ввод\n");
                }
                else
                {
                    newQuery = new DatabaseInteractor(input);
                    tableData = newQuery.ReceiveData();
                }

                Console.WriteLine(menuItems[input - 1]);
                Console.WriteLine(tableData);

                for (var i = 0; i < returnItems.Length; i++)
                    Console.WriteLine($"{i} - {returnItems[i]}");
                exitInputValue = InputHandler(returnItems.Length);
                if (exitInputValue == 1)
                    Environment.Exit(0);

            } while (exitInputValue == 0);
        }

        private int InputHandler(int? checkValue)
        {
            var input = Console.ReadLine();
            var inputParsed = -1;
            Console.Clear();
            if (CheckMenuNumberInput(input) && (int.Parse(input) < checkValue + 1 && int.Parse(input) > 0))
                inputParsed = int.Parse(input);
            else if (CheckMenuNumberInput(input) && checkValue == null)
                inputParsed = int.Parse(input);
            return inputParsed;
        }

        private bool CheckMenuNumberInput(string value)
        {
            var inputCheck = false;
            if (int.TryParse(value, out int valueParsed))
                inputCheck = true;
            return inputCheck;
        }
    }
}

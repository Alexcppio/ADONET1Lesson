﻿use [VegFruits];
go

CREATE TABLE [dbo].[VegFruits]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL CHECK([Name] <> N''), 
    [Type] NVARCHAR(20) NOT NULL CHECK([Type] <> N''), 
    [Color] NVARCHAR(50) NOT NULL CHECK([Color] <> N''), 
    [Calorie_Content] INT NOT NULL DEFAULT 0
)

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Капуста огородная', 'овощ', 'сизовато-зелёный', 24);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Картофель', 'овощ', 'жёлтый', 73);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Морковь', 'овощ', 'оранжевый', 32);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Свекла', 'овощ', 'бордовый', 43);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Томат', 'овощ', 'красный', 18);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Огурец', 'овощ', 'зеленый', 15);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Лук репчатый', 'овощ', 'желтый', 48);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Капуста цветная', 'овощ', 'белый', 28);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Абрикос', 'фрукт', 'оранжевый', 41);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Черешня', 'фрукт', 'бардовый', 50);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Лимон', 'фрукт', 'желтый', 16);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Слива', 'фрукт', 'лиловый', 34);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Гранат', 'фрукт', 'красный', 52);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Мандарин', 'фрукт', 'оранжевый', 33);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Апельсин', 'фрукт', 'оранжевый', 36);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Яблоко Фуджи', 'фрукт', 'красный', 71);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Груша', 'фрукт', 'зеленый', 42);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Персик', 'фрукт', 'красный', 46);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Банан', 'фрукт', 'желтый', 95);

INSERT INTO [VegFruits] ([Name], [Type], [Color], [Calorie_Content])
VALUES ('Хурма', 'фрукт', 'оранжевый', 66);
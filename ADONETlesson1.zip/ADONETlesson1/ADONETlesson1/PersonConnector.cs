﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace ADONETlesson1
{
    public class PersonConnector : IDisposable
{
        private readonly SqlConnection _connection;
        public PersonConnector(string connectString)
        {
            _connection = new SqlConnection(connectString);
        }

        public void GetFirstPersonLikeName(string name)
        {
            if (String.IsNullOrWhiteSpace(name))
                throw new ArgumentNullException(nameof(name));
            using (var cmd = new SqlCommand("SELECT TOP 1 FROM [Persons] WHERE [Name] LIKE @'name%'", _connection))
            {
                cmd.Parameters.AddWithValue("@name", string.Concat('%', name, '%'));
                Console.WriteLine(cmd.ExecuteReader());
            }
        }

        public void Dispose()
        {
            _connection.Dispose();
        }
    }
}

﻿using System;
using System.Data.Common;
using System.Data.SqlClient;

namespace ADONETlesson1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var connection = new PersonConnector(@"Data Source=(localdb\MSSQLLocalDB;Initial Catalog=NewDB;Database=NewDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                connection.GetFirstPersonLikeName("123");
            }

        }
    }
}
